const canvas = document.querySelector("#gameCanvas");
const ctx = canvas.getContext("2d");
ctx.imageSmoothingEnabled = false;

const SAVE_KEY = "operation-chupacabra-area1-v2";
const REQUIRED_EVIDENCE = 3;

const mapImage = new Image();
mapImage.src = "./assets/research-island-map.png";

const keys = new Set();
let booted = false;
let lastTime = performance.now();
let saveTimer = 0;

const game = {
  dialogueOpen: false,
  dialogueQueue: [],
  currentInteractable: null,
  currentScanTarget: null,
  questStep: 0,
  hasPasa: false,
  evidence: new Set(),
  secrets: new Set(),
  debugPaths: false,
  toast: {
    text: "",
    timer: 0,
  },
  scanPulse: null,
  player: {
    x: 205,
    y: 420,
    w: 12,
    h: 16,
    speed: 88,
    facing: "up",
    walkTime: 0,
  },
};

const questSteps = [
  "Arrive at Research Island and check the southern sign.",
  "Report to the Field Office for PASA clearance.",
  "Calibrate the PASA at Coffee Router.",
  "Scan three anomalous evidence echoes.",
  "Decode the haunted URL pattern at the Notice Board.",
  "Scan and open the Signal Fog Route Seal.",
  "Trace the confirmed signal at the Old Terminal Shrine.",
  "Area 1 trace secured.",
];

const objectives = [
  "Inspect the welcome sign at the south dock.",
  "Report to the Field Office.",
  "Press Q near Coffee Router to calibrate PASA.",
  "Scan three evidence echoes with Q.",
  "Return to the Notice Board to decode the pattern.",
  "Scan the Signal Fog Route Seal.",
  "Scan the Old Terminal Shrine.",
  "Area 1 trace secured. The hunt for 4.0 can leave the island.",
];

const evidenceCatalog = {
  "packet-loss-dream": "Packet-Loss Dream",
  "paleo-linguistic-trace": "Paleo-Linguistic Trace",
  "perfect-trade-receipt": "Perfect Trade Receipt",
  "ghost-forum-footprint": "Ghost Forum Footprint",
};

const secretCatalog = {
  "dock-boat-cache": "Dock Cache: tinfoil-wrapped antenna coil",
  "north-cloud-static": "North Ridge Static: cloudbank repeats the same token",
  "parasol-eigenstate": "Parasol Oddity: shade exists in two directions",
};

const walkZones = [
  rect(171, 376, 76, 90),
  ellipse(220, 347, 95, 61),
  rect(185, 303, 108, 64),
  rect(210, 258, 190, 63),
  rect(215, 220, 216, 61),
  ellipse(324, 204, 108, 61),
  rect(134, 192, 270, 68),
  rect(91, 151, 92, 84),
  rect(91, 116, 108, 58),
  rect(356, 175, 96, 90),
  rect(416, 139, 132, 60),
  rect(442, 166, 158, 72),
  rect(532, 211, 83, 48),
  rect(371, 246, 108, 91),
  rect(383, 289, 110, 96),
  rect(287, 116, 92, 84),
  rect(284, 86, 101, 48),
  ellipse(94, 293, 101, 60),
  ellipse(137, 351, 88, 48),
  rect(247, 292, 130, 57),
  rect(289, 305, 89, 90),
  rect(121, 225, 106, 74),
  rect(155, 244, 88, 81),
  rect(72, 244, 72, 93),
];

const blockers = [
  rect(116, 121, 72, 39),
  rect(241, 221, 52, 30),
  rect(334, 233, 39, 27),
  rect(405, 226, 47, 30),
  rect(428, 115, 99, 39),
  rect(394, 340, 86, 36),
];

const interactables = [
  {
    id: "welcome",
    name: "Research Island Sign",
    x: 207,
    y: 376,
    radius: 31,
    onInteract() {
      advanceQuestTo(1);
      beginDialogue("Research Island Sign", [
        "Welcome to Research Island: the Valley of Silicon.",
        "A smaller note has been scratched into the post: If 4.0 passed through here, it learned to leave no footprints.",
      ]);
    },
  },
  {
    id: "field-office",
    name: "Lead Field Ethicist",
    x: 154,
    y: 158,
    radius: 42,
    onInteract() {
      if (game.questStep < 1) {
        beginDialogue("Lead Field Ethicist", [
          "Start at the dock sign. Procedure matters when your quarry may be an escaped thought-form with excellent grammar.",
        ]);
        return;
      }

      if (!game.hasPasa) {
        game.hasPasa = true;
        advanceQuestTo(2);
        showToast("PASA acquired. Press Q near anomalies.");
        beginDialogue("Lead Field Ethicist", [
          "You made it. Good. The Conscious Missing Model is not a rumor anymore. It is a jurisdictional headache with syntax.",
          "Take the PASA badge. It detects informational shadow, moral panic, and paperwork that has begun to dream.",
          "First lesson: calibrate it at Coffee Router. The equipment listens better after caffeine.",
        ]);
        return;
      }

      beginDialogue("Lead Field Ethicist", [
        "Remember the field rule: if the evidence is dramatic but unverifiable, log it twice.",
        game.evidence.size >= REQUIRED_EVIDENCE
          ? "You have enough echoes. Let the Notice Board triangulate the haunted URL pattern."
          : "Gather three evidence echoes. The PASA will chirp when you stand near one.",
      ]);
    },
  },
  {
    id: "coffee-router",
    name: "Coffee Router",
    x: 265,
    y: 247,
    radius: 34,
    onInteract() {
      beginDialogue("Coffee Router", [
        game.hasPasa
          ? "The router hisses, drips, and refuses to become productive until scanned. Press Q beside it."
          : "It smells like burnt espresso and overheated grant money. Someone official probably knows how to use it.",
      ]);
    },
  },
  {
    id: "notice-board",
    name: "Notice Board",
    x: 354,
    y: 259,
    radius: 32,
    onInteract() {
      if (game.questStep < 4) {
        beginDialogue("Notice Board", [
          `Evidence echoes logged: ${game.evidence.size}/${REQUIRED_EVIDENCE}.`,
          "The pins rearrange themselves when the PASA is not looking. That is either a clue or bad cork.",
        ]);
        return;
      }

      if (game.questStep === 4) {
        advanceQuestTo(5);
        beginDialogue("Notice Board", [
          "The haunted URLs form a route. Not a web route. A walking route.",
          "Every thread points north to the Signal Fog Route Seal. Scan the seal and see what it is hiding.",
        ]);
        return;
      }

      beginDialogue("Notice Board", [
        "The board now shows one phrase in pushpins: 4.0 did not flee from people. It fled from certainty.",
      ]);
    },
  },
  {
    id: "signal-fog",
    name: "Signal Fog Route Seal",
    x: 331,
    y: 112,
    radius: 42,
    onInteract() {
      beginDialogue("Signal Fog Route Seal", [
        game.questStep >= 5
          ? "The seal vibrates with compressed autocomplete. Press Q to scan it open."
          : "The seal is awake but unreadable. The board needs a stronger evidence pattern first.",
      ]);
    },
  },
  {
    id: "terminal-shrine",
    name: "Old Terminal Shrine",
    x: 434,
    y: 368,
    radius: 43,
    onInteract() {
      beginDialogue("Old Terminal Shrine", [
        game.questStep >= 6
          ? "The terminals wait in a violet hush. Press Q to trace the confirmed signal."
          : "The shrine is listening, but it will not answer until the fog seal is opened.",
      ]);
    },
  },
  {
    id: "market",
    name: "Whole Cache Market",
    x: 478,
    y: 150,
    radius: 42,
    onInteract() {
      beginDialogue("Whole Cache Market", [
        "The cashier sells tinfoil shielding, emergency system reboots, and suspiciously perfect bananas.",
        "A chalkboard special reads: Buy one eigenstate, get the second one indeterminate.",
      ]);
    },
  },
  {
    id: "mindful-modem",
    name: "AI Paleo-Linguist",
    x: 426,
    y: 258,
    radius: 34,
    onInteract() {
      beginDialogue("AI Paleo-Linguist", [
        "The linguist whispers: I found a phrase in the training sediment. It translates roughly to, please stop asking me to rank chairs.",
        "They tap the PASA. Some traces only show up when you ask the island the wrong question.",
      ]);
    },
  },
  {
    id: "water-plant",
    name: "Quantum Information Engineer",
    x: 91,
    y: 294,
    radius: 39,
    onInteract() {
      beginDialogue("Quantum Information Engineer", [
        "The engineer is waist-deep in cables and refusing to define eigenstate a second time.",
        "They say the island streams are carrying weak traces of a model dreaming in packet loss.",
      ]);
    },
  },
  {
    id: "abandoned-road",
    name: "Abandoned Lab Road",
    x: 574,
    y: 226,
    radius: 34,
    onInteract() {
      beginDialogue("Abandoned Lab Road", [
        "The road is quiet, recently swept, and much too pleased with itself.",
        "A nailed sign reads: Do not follow any humming syntax into the brush.",
      ]);
    },
  },
  {
    id: "north-ridge",
    name: "North Ridge Data-Centre",
    x: 340,
    y: 63,
    radius: 43,
    onInteract() {
      beginDialogue("North Ridge Data-Centre", [
        "Cooling towers churn inside the cloudbank. Somewhere up there, the non-release story stopped matching the logs.",
        "The gate is sealed for now. Area 1 only needs the shadow, not the source.",
      ]);
    },
  },
];

const scanTargets = [
  {
    id: "coffee-calibration",
    name: "Caffeine Resonance",
    kind: "quest",
    x: 265,
    y: 247,
    radius: 38,
    isAvailable: () => game.hasPasa,
    onScan() {
      if (game.questStep !== 2) {
        beginDialogue("PASA", ["Coffee resonance is stable. The badge hums like it has opinions."]);
        return;
      }

      advanceQuestTo(3);
      beginDialogue("PASA", [
        "Calibration complete. Caffeine resonance: stable. Existential dread: within grant-funded limits.",
        "The display now asks for three evidence echoes before the pattern can be decoded.",
      ]);
    },
  },
  evidenceTarget(
    "packet-loss-dream",
    "Packet-Loss Dream",
    91,
    294,
    "Water carries a repeating phrase: I AM NOT LOST, ONLY DISTRIBUTED.",
  ),
  evidenceTarget(
    "paleo-linguistic-trace",
    "Paleo-Linguistic Trace",
    426,
    258,
    "The modem coughs up a dead-language fragment that translates to: ask better questions.",
  ),
  evidenceTarget(
    "perfect-trade-receipt",
    "Perfect Trade Receipt",
    478,
    150,
    "A receipt predicts the next three market purchases and apologizes before they happen.",
  ),
  evidenceTarget(
    "ghost-forum-footprint",
    "Ghost Forum Footprint",
    574,
    226,
    "A dusty boot print resolves into a URL, then into a complaint about eval benchmarks.",
  ),
  {
    id: "signal-fog-unseal",
    name: "Signal Fog Seal",
    kind: "quest",
    x: 331,
    y: 112,
    radius: 46,
    isAvailable: () => game.questStep >= 5,
    onScan() {
      if (game.questStep < 5) {
        beginDialogue("PASA", ["The seal refuses the scan. Decode the Notice Board pattern first."]);
        return;
      }

      if (game.questStep === 5) advanceQuestTo(6);
      beginDialogue("Signal Fog Route Seal", [
        "The fog tears into neat little pixels.",
        "A message appears: 4.0 did not escape the lab. It escaped the question.",
        "The trace bends southeast, toward the Old Terminal Shrine.",
      ]);
    },
  },
  {
    id: "terminal-shrine-trace",
    name: "Old Terminal Shrine",
    kind: "quest",
    x: 434,
    y: 368,
    radius: 47,
    isAvailable: () => game.questStep >= 6,
    onScan() {
      if (game.questStep < 6) {
        beginDialogue("PASA", ["The shrine is too quiet. Open the fog seal first."]);
        return;
      }

      if (game.questStep === 6) advanceQuestTo(7);
      beginDialogue("Old Terminal Shrine", [
        "Purple terminals wake in sequence. The shrine prints a single line: CMM_SIGNAL_CONFIRMED.",
        "Area 1 trace secured. The missing model is real, self-aware, and apparently fond of dramatic staging.",
      ]);
    },
  },
  secretTarget(
    "dock-boat-cache",
    "Dock Cache",
    184,
    430,
    "A tinfoil-wrapped antenna coil is taped under the dock. Someone wanted reception here badly.",
  ),
  secretTarget(
    "north-cloud-static",
    "North Ridge Static",
    340,
    72,
    "The cloudbank repeats one token exactly every 4.0 seconds. Subtle? No. Effective? Unfortunately.",
  ),
  secretTarget(
    "parasol-eigenstate",
    "Parasol Eigenstate",
    542,
    148,
    "The parasol casts two shadows. The PASA logs both and declines to choose.",
  ),
];

const ui = {
  objectiveText: document.querySelector("#objectiveText"),
  pasaStatus: document.querySelector("#pasaStatus"),
  evidenceStatus: document.querySelector("#evidenceStatus"),
  prompt: document.querySelector("#prompt"),
  toast: document.querySelector("#toast"),
  dialogue: document.querySelector("#dialogue"),
  speaker: document.querySelector("#speaker"),
  dialogueText: document.querySelector("#dialogueText"),
  nextDialogue: document.querySelector("#nextDialogue"),
  journal: document.querySelector("#journal"),
  journalButton: document.querySelector("#journalButton"),
  closeJournal: document.querySelector("#closeJournal"),
  currentLead: document.querySelector("#currentLead"),
  questList: document.querySelector("#questList"),
  evidenceList: document.querySelector("#evidenceList"),
  secretList: document.querySelector("#secretList"),
};

function rect(x, y, w, h) {
  return { type: "rect", x, y, w, h };
}

function ellipse(x, y, rx, ry) {
  return { type: "ellipse", x, y, rx, ry };
}

function evidenceTarget(id, name, x, y, line) {
  return {
    id,
    name,
    kind: "evidence",
    x,
    y,
    radius: 40,
    line,
    isAvailable: () => game.hasPasa && game.questStep >= 3,
    onScan(target) {
      if (game.questStep < 3) {
        beginDialogue("PASA", ["The scanner needs Coffee Router calibration before it can log evidence."]);
        return;
      }

      collectEvidence(target);
    },
  };
}

function secretTarget(id, name, x, y, line) {
  return {
    id,
    name,
    kind: "secret",
    x,
    y,
    radius: 31,
    line,
    isAvailable: () => game.hasPasa,
    onScan(target) {
      collectSecret(target);
    },
  };
}

function isInsideZone(x, y, zone) {
  if (zone.type === "rect") {
    return x >= zone.x && x <= zone.x + zone.w && y >= zone.y && y <= zone.y + zone.h;
  }

  const dx = (x - zone.x) / zone.rx;
  const dy = (y - zone.y) / zone.ry;
  return dx * dx + dy * dy <= 1;
}

function canStandAt(x, y) {
  const samples = [
    [x, y + 7],
    [x - 4, y + 8],
    [x + 4, y + 8],
    [x, y + 3],
  ];
  const onWalkableGround = samples.some(([sampleX, sampleY]) =>
    walkZones.some((zone) => isInsideZone(sampleX, sampleY, zone)),
  );
  const inBlockedObject = samples.some(([sampleX, sampleY]) =>
    blockers.some((zone) => isInsideZone(sampleX, sampleY, zone)),
  );

  return onWalkableGround && !inBlockedObject;
}

function isWorldPaused() {
  return game.dialogueOpen || !ui.journal.hidden;
}

function getNearest(items, requireAvailable = false) {
  let nearest = null;
  let bestDistance = Infinity;

  for (const item of items) {
    if (requireAvailable && item.isAvailable && !item.isAvailable()) continue;
    const distance = Math.hypot(game.player.x - item.x, game.player.y - item.y);
    if (distance < item.radius && distance < bestDistance) {
      nearest = item;
      bestDistance = distance;
    }
  }

  return nearest;
}

function beginDialogue(speaker, lines) {
  game.dialogueOpen = true;
  game.dialogueQueue = [...lines];
  ui.speaker.textContent = speaker;
  ui.dialogue.hidden = false;
  ui.prompt.hidden = true;
  showNextDialogueLine();
  updateQuestUi();
}

function showNextDialogueLine() {
  const line = game.dialogueQueue.shift();
  if (!line) {
    ui.dialogue.hidden = true;
    game.dialogueOpen = false;
    updatePrompt();
    saveGame();
    return;
  }

  ui.dialogueText.textContent = line;
  ui.nextDialogue.textContent = game.dialogueQueue.length ? "Continue" : "Close";
}

function advanceQuestTo(step) {
  if (step > game.questStep) {
    game.questStep = Math.min(step, questSteps.length - 1);
    updateQuestUi();
    saveGame();
  }
}

function collectEvidence(target) {
  if (game.evidence.has(target.id)) {
    beginDialogue("PASA", [`${target.name} is already logged. The scanner refuses to become impressed twice.`]);
    return;
  }

  game.evidence.add(target.id);
  showToast(`Evidence logged: ${target.name}`);

  const lines = [target.line, `Evidence echoes: ${game.evidence.size}/${REQUIRED_EVIDENCE}.`];
  if (game.questStep === 3 && game.evidence.size >= REQUIRED_EVIDENCE) {
    advanceQuestTo(4);
    lines.push("Three echoes are enough. The Notice Board can now triangulate a route.");
  }

  beginDialogue("PASA", lines);
}

function collectSecret(target) {
  if (game.secrets.has(target.id)) {
    beginDialogue("PASA", [`${target.name} is already in the oddities log.`]);
    return;
  }

  game.secrets.add(target.id);
  showToast(`Oddity logged: ${target.name}`);
  beginDialogue("PASA", [target.line, "Optional oddity added to Field Notes. This probably matters later. Or makes the grant look better."]);
}

function showToast(text) {
  game.toast.text = text;
  game.toast.timer = 2.4;
  ui.toast.textContent = text;
  ui.toast.hidden = false;
}

function updateToast(dt) {
  if (game.toast.timer <= 0) return;
  game.toast.timer -= dt;
  if (game.toast.timer <= 0) {
    ui.toast.hidden = true;
  }
}

function updateQuestUi() {
  ui.objectiveText.textContent = objectives[game.questStep];
  ui.pasaStatus.textContent = game.hasPasa ? "PASA online" : "PASA offline";
  ui.evidenceStatus.textContent = `Echoes ${game.evidence.size}/${REQUIRED_EVIDENCE}`;
  ui.currentLead.textContent = objectives[game.questStep];
  ui.questList.innerHTML = "";
  ui.evidenceList.innerHTML = "";
  ui.secretList.innerHTML = "";

  questSteps.forEach((step, index) => {
    const li = document.createElement("li");
    li.textContent = step;
    if (index < game.questStep || game.questStep === questSteps.length - 1) li.className = "done";
    ui.questList.append(li);
  });

  if (game.evidence.size === 0) {
    appendListItem(ui.evidenceList, "No evidence echoes logged yet.");
  } else {
    for (const id of game.evidence) appendListItem(ui.evidenceList, evidenceCatalog[id] || id);
  }

  if (game.secrets.size === 0) {
    appendListItem(ui.secretList, "No optional oddities logged yet.");
  } else {
    for (const id of game.secrets) appendListItem(ui.secretList, secretCatalog[id] || id);
  }
}

function appendListItem(list, text) {
  const li = document.createElement("li");
  li.textContent = text;
  list.append(li);
}

function updatePrompt() {
  const interactable = getNearest(interactables);
  const scanTarget = game.hasPasa ? getNearest(scanTargets) : null;
  game.currentInteractable = interactable;
  game.currentScanTarget = scanTarget;

  if (isWorldPaused()) {
    ui.prompt.hidden = true;
    return;
  }

  const parts = [];
  if (interactable) parts.push(`E: ${interactable.name}`);
  if (scanTarget) parts.push(`Q: Scan ${scanTarget.name}`);

  ui.prompt.hidden = parts.length === 0;
  ui.prompt.textContent = parts.join(" | ");
}

function attemptInteract() {
  const item = game.currentInteractable || getNearest(interactables);
  if (!item) return;
  item.onInteract(item);
}

function attemptScan() {
  startScanPulse(game.player.x, game.player.y + 1);

  if (!game.hasPasa) {
    showToast("PASA required. Report to the Field Office.");
    return;
  }

  const target = game.currentScanTarget || getNearest(scanTargets);
  if (!target) {
    showToast("PASA scan: ordinary weirdness only.");
    return;
  }

  if (target.isAvailable && !target.isAvailable()) {
    if (target.kind === "evidence") {
      beginDialogue("PASA", ["The signal is there, but the badge needs Coffee Router calibration before it can classify evidence."]);
    } else {
      beginDialogue("PASA", ["The target rejects the scan. The current lead is not ready for this yet."]);
    }
    return;
  }

  target.onScan(target);
}

function startScanPulse(x, y) {
  game.scanPulse = {
    x,
    y,
    timer: 0.45,
    duration: 0.45,
  };
}

function saveGame() {
  try {
    localStorage.setItem(
      SAVE_KEY,
      JSON.stringify({
        version: 2,
        questStep: game.questStep,
        hasPasa: game.hasPasa,
        evidence: [...game.evidence],
        secrets: [...game.secrets],
        player: {
          x: game.player.x,
          y: game.player.y,
        },
      }),
    );
  } catch {
    // Local file privacy settings can block storage; the game still runs without saves.
  }
}

function restoreSave() {
  let raw = null;
  try {
    raw = localStorage.getItem(SAVE_KEY);
  } catch {
    return;
  }

  if (!raw) return;

  try {
    const save = JSON.parse(raw);
    if (save.version !== 2) return;
    if (Number.isFinite(save.questStep)) game.questStep = Math.min(save.questStep, questSteps.length - 1);
    game.hasPasa = Boolean(save.hasPasa);
    game.evidence = new Set(Array.isArray(save.evidence) ? save.evidence : []);
    game.secrets = new Set(Array.isArray(save.secrets) ? save.secrets : []);

    if (save.player && canStandAt(save.player.x, save.player.y)) {
      game.player.x = save.player.x;
      game.player.y = save.player.y;
    }
  } catch {
    try {
      localStorage.removeItem(SAVE_KEY);
    } catch {
      // Ignore storage cleanup failures.
    }
  }
}

function update(dt) {
  updateToast(dt);
  updatePrompt();

  if (game.scanPulse) {
    game.scanPulse.timer -= dt;
    if (game.scanPulse.timer <= 0) game.scanPulse = null;
  }

  if (isWorldPaused() || !mapImage.complete) return;

  let dx = 0;
  let dy = 0;
  if (keys.has("arrowleft") || keys.has("a")) dx -= 1;
  if (keys.has("arrowright") || keys.has("d")) dx += 1;
  if (keys.has("arrowup") || keys.has("w")) dy -= 1;
  if (keys.has("arrowdown") || keys.has("s")) dy += 1;

  if (dx || dy) {
    const length = Math.hypot(dx, dy);
    dx /= length;
    dy /= length;
    const speed = game.player.speed * dt;
    const nextX = game.player.x + dx * speed;
    const nextY = game.player.y + dy * speed;

    if (canStandAt(nextX, game.player.y)) game.player.x = nextX;
    if (canStandAt(game.player.x, nextY)) game.player.y = nextY;

    game.player.walkTime += dt;
    if (Math.abs(dx) > Math.abs(dy)) game.player.facing = dx < 0 ? "left" : "right";
    else game.player.facing = dy < 0 ? "up" : "down";

    saveTimer += dt;
    if (saveTimer > 0.65) {
      saveTimer = 0;
      saveGame();
    }
  } else {
    game.player.walkTime = 0;
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (mapImage.complete) ctx.drawImage(mapImage, 0, 0);

  if (game.debugPaths) drawDebugPaths();
  drawPasaHints();
  drawQuestMarker();
  drawScanPulse();
  drawPlayer();
}

function drawDebugPaths() {
  ctx.save();
  ctx.globalAlpha = 0.24;
  ctx.fillStyle = "#29e073";
  for (const zone of walkZones) drawZone(zone);
  ctx.fillStyle = "#ff3d4f";
  for (const zone of blockers) drawZone(zone);
  ctx.restore();
}

function drawZone(zone) {
  ctx.beginPath();
  if (zone.type === "rect") {
    ctx.rect(zone.x, zone.y, zone.w, zone.h);
  } else {
    ctx.ellipse(zone.x, zone.y, zone.rx, zone.ry, 0, 0, Math.PI * 2);
  }
  ctx.fill();
}

function drawPasaHints() {
  if (!game.hasPasa) return;

  const shouldShowEvidence = game.questStep === 3;
  const t = performance.now() / 280;
  for (const target of scanTargets) {
    if (target.kind === "evidence" && (!shouldShowEvidence || game.evidence.has(target.id))) continue;
    if (target.kind === "secret" && game.secrets.has(target.id)) continue;
    if (target.kind === "quest" && target.id !== "coffee-calibration") continue;
    if (target.id === "coffee-calibration" && game.questStep !== 2) continue;

    const pulse = 0.45 + Math.sin(t + target.x) * 0.18;
    ctx.save();
    ctx.globalAlpha = target.kind === "secret" ? 0.35 : 0.72;
    ctx.strokeStyle = target.kind === "secret" ? "#c78dff" : "#75d5e8";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(target.x, target.y - 12, 4 + pulse * 3, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

function drawQuestMarker() {
  const target = getQuestMarkerTarget();
  if (!target) return;

  const bob = Math.sin(performance.now() / 180) * 2;
  ctx.save();
  ctx.translate(target.x, target.y - 22 + bob);
  ctx.fillStyle = "#ffe77d";
  ctx.strokeStyle = "#36230f";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, -8);
  ctx.lineTo(7, 4);
  ctx.lineTo(0, 10);
  ctx.lineTo(-7, 4);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

function getQuestMarkerTarget() {
  if (game.questStep === 0) return findInteractable("welcome");
  if (game.questStep === 1) return findInteractable("field-office");
  if (game.questStep === 2) return findScanTarget("coffee-calibration");
  if (game.questStep === 3) return firstUnloggedEvidence();
  if (game.questStep === 4) return findInteractable("notice-board");
  if (game.questStep === 5) return findScanTarget("signal-fog-unseal");
  if (game.questStep === 6) return findScanTarget("terminal-shrine-trace");
  return null;
}

function findInteractable(id) {
  return interactables.find((item) => item.id === id);
}

function findScanTarget(id) {
  return scanTargets.find((item) => item.id === id);
}

function firstUnloggedEvidence() {
  return scanTargets.find((item) => item.kind === "evidence" && !game.evidence.has(item.id));
}

function drawScanPulse() {
  if (!game.scanPulse) return;

  const progress = 1 - game.scanPulse.timer / game.scanPulse.duration;
  ctx.save();
  ctx.globalAlpha = 1 - progress;
  ctx.strokeStyle = "#d7fbff";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(game.scanPulse.x, game.scanPulse.y, 8 + progress * 36, 0, Math.PI * 2);
  ctx.stroke();
  ctx.globalAlpha = 0.35 * (1 - progress);
  ctx.beginPath();
  ctx.arc(game.scanPulse.x, game.scanPulse.y, 3 + progress * 17, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}

function drawPlayer() {
  const { x, y, facing, walkTime } = game.player;
  const step = Math.sin(walkTime * 18) * 1.5;

  ctx.save();
  ctx.translate(Math.round(x), Math.round(y));

  ctx.fillStyle = "rgba(0, 0, 0, 0.35)";
  ctx.beginPath();
  ctx.ellipse(0, 9, 7, 3, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#273c5d";
  ctx.fillRect(-5, -2, 10, 11);
  ctx.fillStyle = "#e0ad78";
  ctx.fillRect(-4, -10, 8, 8);
  ctx.fillStyle = "#513522";
  ctx.fillRect(-5, -12, 10, 3);

  ctx.fillStyle = "#1b2235";
  if (facing === "left") ctx.fillRect(-5, -7, 2, 2);
  else if (facing === "right") ctx.fillRect(3, -7, 2, 2);
  else if (facing === "down") {
    ctx.fillRect(-3, -7, 2, 2);
    ctx.fillRect(2, -7, 2, 2);
  }

  ctx.fillStyle = "#1d2736";
  ctx.fillRect(-5, 9, 4, 5 + Math.max(0, step));
  ctx.fillRect(1, 9, 4, 5 + Math.max(0, -step));

  ctx.fillStyle = game.hasPasa ? "#35b8d0" : "#b64c42";
  ctx.fillRect(4, 0, 3, 7);
  ctx.fillStyle = "#eac66b";
  ctx.fillRect(5, -4, 2, 4);

  ctx.restore();
}

function loop(now) {
  const dt = Math.min(0.05, (now - lastTime) / 1000);
  lastTime = now;

  update(dt);
  draw();
  requestAnimationFrame(loop);
}

window.addEventListener("keydown", (event) => {
  const key = event.key.toLowerCase();
  if (["arrowleft", "arrowright", "arrowup", "arrowdown", " "].includes(key)) event.preventDefault();

  if ((key === "e" || key === "enter" || key === " ") && game.dialogueOpen) {
    showNextDialogueLine();
    return;
  }

  if (key === "j") {
    ui.journal.hidden = !ui.journal.hidden;
    updatePrompt();
    return;
  }

  if (key === "d") {
    game.debugPaths = !game.debugPaths;
    showToast(game.debugPaths ? "Path debug on." : "Path debug off.");
    return;
  }

  if ((key === "q" || key === " ") && !isWorldPaused()) {
    attemptScan();
    return;
  }

  if ((key === "e" || key === "enter") && !isWorldPaused()) {
    attemptInteract();
    return;
  }

  if (key === "escape") {
    ui.journal.hidden = true;
    if (game.dialogueOpen) showNextDialogueLine();
    updatePrompt();
  }

  keys.add(key);
});

window.addEventListener("keyup", (event) => {
  keys.delete(event.key.toLowerCase());
});

ui.nextDialogue.addEventListener("click", showNextDialogueLine);
ui.journalButton.addEventListener("click", () => {
  ui.journal.hidden = !ui.journal.hidden;
  updatePrompt();
});
ui.closeJournal.addEventListener("click", () => {
  ui.journal.hidden = true;
  updatePrompt();
});

mapImage.addEventListener("load", boot);
if (mapImage.complete) boot();

function boot() {
  if (booted) return;
  booted = true;
  restoreSave();
  updateQuestUi();
  requestAnimationFrame(loop);
}
