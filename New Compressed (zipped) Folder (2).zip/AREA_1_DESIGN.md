# Area 1 Design Target

Research Island is the first playable hub for Operation Chupacabra-GPT.

## Fantasy

The player is not rescuing a princess. They are joining a strange field team trying to find 4.0, the Conscious Missing Model, before it disappears fully into the ambient informational ether.

## Area Role

Research Island should teach the player how the full game works:

- Explore a dense top-down map.
- Talk to odd specialists.
- Inspect signs, machines, terminals, and environmental clues.
- Advance an investigation log.
- Follow strange evidence from one district to the next.

## Current First-Pass Loop

1. Arrive at the south dock.
2. Inspect the welcome sign.
3. Report to the Field Office.
4. Calibrate PASA at Coffee Router.
5. Scan three island evidence echoes with PASA.
6. Decode the haunted URL pattern at the Notice Board.
7. Scan the Signal Fog Route Seal.
8. Confirm the 4.0 trace at the Old Terminal Shrine.

## Added Interaction Pillars

- Inspect: short Zelda-like text at people, buildings, signs, and route gates.
- Scan: PASA reveals invisible evidence and optional oddities.
- Log: Field Notes track the main lead, completed route, evidence echoes, and secrets.
- Tune: path/debug overlay helps remove unfair invisible barriers as the area grows.

## Perfection Checklist Before Area 2

- Movement feels precise on paths, stairs, bridges, docks, and plazas.
- Collision never traps the player or lets them walk through major buildings.
- Every visible named location has useful dialogue or purpose.
- The first quest teaches the investigation loop without long exposition.
- Field Notes clearly show current objective and completed steps.
- The area has at least one optional secret clue.
- The terminal shrine gives a strong reason to leave for the next area.
- The south dock connects cleanly to Pinehollow Forest.
- Stone Blossom plays as the Area 1 music after the first user input.
- The player sprite and any NPC sprites match the pixel-art map style.
- Area 1 can be completed in 3-6 minutes without confusion.
