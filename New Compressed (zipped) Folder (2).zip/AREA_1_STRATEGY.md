# Area 1 Build Strategy

This section is the first readable slice of the full game, so it should prove the loop before the game grows.

## Reference Lessons

Games like Zelda: A Link to the Past make early areas work by combining a few simple ideas:

- A readable overworld with obvious paths and gates.
- One new verb or item that changes how the player reads the world.
- Short NPC/sign dialogue that points without overexplaining.
- Optional secrets near the main route.
- A final local payoff that hints at the next area.

For Operation Chupacabra-GPT, the replacement for sword/item discovery is field investigation. The player is not becoming stronger by fighting yet; they are becoming more capable by learning how to detect traces of 4.0.

## Implemented Overnight Slice

1. Movement Tune
   - Widened and softened the walkable path mask.
   - Reduced harsh building blockers.
   - Added a `D` debug overlay for walkable and blocked zones.

2. PASA Item Verb
   - Field Office grants PASA.
   - `Q` scans the world.
   - Coffee Router teaches calibration before evidence gathering.

3. Evidence Loop
   - Three evidence echoes are required to progress.
   - Evidence can be collected from multiple island landmarks.
   - Field Notes track collected echoes.

4. Optional Secrets
   - PASA can also find oddities that are not required.
   - Secrets support replay and make the map feel less flat.

5. Local Gate and Payoff
   - Notice Board decodes the evidence pattern.
   - Signal Fog Route Seal becomes the local gate.
   - Old Terminal Shrine confirms the first 4.0 signal.

6. Area Connection and Music
   - South dock now transfers into Pinehollow Forest.
   - Pinehollow dock transfers back to Research Island.
   - Stone Blossom is the Research Island music.
   - Rudder of Fate is the Pinehollow Forest music.

## Next Pass Priorities

1. Replace the simple player marker with a proper sprite sheet.
2. Add two or three NPC sprites with small idle animations.
3. Tune collision by walking every route with the debug overlay.
4. Add one tiny environmental puzzle, such as rerouting water or powering a terminal.
5. Add an Area 1 completion transition that points to the next map.
6. Decide whether combat exists in Area 1 or waits until Area 2.

## Did I Rush This Check

The movement fix would have been rushed if it only expanded rectangles. The debug overlay was added because this area needs repeated tuning, not one lucky guess. The evidence loop is still first-pass, but it now has a real structure: get tool, calibrate tool, gather traces, decode traces, unlock gate, confirm signal.
