const canvas = document.querySelector("#gameCanvas");
const ctx = canvas.getContext("2d");
ctx.imageSmoothingEnabled = false;

const VIEW_WIDTH = 640;
const VIEW_HEIGHT = 481;
const SAVE_KEY = "operation-chupacabra-game-v3";
const REQUIRED_EVIDENCE = 3;

const images = {
  research: loadImage("./assets/research-island-map.png"),
  pinehollow: loadImage("./assets/pinehollow-forest-map.jpg"),
};

const music = new Audio();
music.loop = true;
music.volume = 0.46;

const tracks = {
  research: {
    title: "Stone Blossom",
    src: "./assets/stone-blossom.mp3",
  },
  pinehollow: {
    title: "Rudder of Fate",
    src: "./assets/rudder-of-fate.mp3",
  },
};

const keys = new Set();
let booted = false;
let audioUnlocked = false;
let currentTrackKey = "";
let lastTime = performance.now();
let saveTimer = 0;

const game = {
  areaId: "research",
  dialogueOpen: false,
  dialogueQueue: [],
  currentInteractable: null,
  currentScanTarget: null,
  currentTransfer: null,
  questStep: 0,
  hasPasa: false,
  evidence: new Set(),
  secrets: new Set(),
  pinehollowVisited: new Set(),
  debugPaths: false,
  toast: {
    text: "",
    timer: 0,
  },
  scanPulse: null,
  transition: {
    timer: 0,
    text: "",
  },
  player: {
    x: 205,
    y: 420,
    w: 12,
    h: 16,
    speed: 92,
    facing: "up",
    walkTime: 0,
  },
};

const questSteps = [
  "Arrive at Research Island and check the southern sign.",
  "Report to the Field Office for PASA clearance.",
  "Calibrate the PASA at Coffee Router.",
  "Scan three anomalous evidence echoes.",
  "Decode the haunted URL pattern at the Notice Board.",
  "Scan and open the Signal Fog Route Seal.",
  "Trace the confirmed signal at the Old Terminal Shrine.",
  "Walk to the south dock and sail for Pinehollow Forest.",
];

const researchObjectives = [
  "Inspect the welcome sign at the south dock.",
  "Report to the Field Office.",
  "Press Q near Coffee Router to calibrate PASA.",
  "Scan three evidence echoes with Q.",
  "Return to the Notice Board to decode the pattern.",
  "Scan the Signal Fog Route Seal.",
  "Scan the Old Terminal Shrine.",
  "Use the south dock to walk through to Pinehollow Forest.",
];

const pinehollowSteps = [
  "Arrive at Pinehollow Forest Access.",
  "Reach the Trailhead.",
  "Find the Trail Hub.",
  "Inspect the Deep Signal Zone.",
  "Optional: question Bigfoot, the hiker, the unicorn grove, and the Whisper Tree.",
];

const evidenceCatalog = {
  "packet-loss-dream": "Packet-Loss Dream",
  "paleo-linguistic-trace": "Paleo-Linguistic Trace",
  "perfect-trade-receipt": "Perfect Trade Receipt",
  "ghost-forum-footprint": "Ghost Forum Footprint",
};

const secretCatalog = {
  "dock-boat-cache": "Dock Cache: tinfoil-wrapped antenna coil",
  "north-cloud-static": "North Ridge Static: cloudbank repeats the same token",
  "parasol-eigenstate": "Parasol Oddity: shade exists in two directions",
};

const areas = {
  research: {
    id: "research",
    name: "Research Island",
    imageKey: "research",
    width: 640,
    height: 481,
    musicKey: "research",
    objective: () => researchObjectives[game.questStep],
    start: { x: 205, y: 420, facing: "up" },
    walkZones: [
      rect(171, 376, 76, 90),
      ellipse(220, 347, 95, 61),
      rect(185, 303, 108, 64),
      rect(210, 258, 190, 63),
      rect(215, 220, 216, 61),
      ellipse(324, 204, 108, 61),
      rect(134, 192, 270, 68),
      rect(91, 151, 92, 84),
      rect(91, 116, 108, 58),
      rect(356, 175, 96, 90),
      rect(416, 139, 132, 60),
      rect(442, 166, 158, 72),
      rect(532, 211, 83, 48),
      rect(371, 246, 108, 91),
      rect(383, 289, 110, 96),
      rect(287, 116, 92, 84),
      rect(284, 86, 101, 48),
      ellipse(94, 293, 101, 60),
      ellipse(137, 351, 88, 48),
      rect(247, 292, 130, 57),
      rect(289, 305, 89, 90),
      rect(121, 225, 106, 74),
      rect(155, 244, 88, 81),
      rect(72, 244, 72, 93),
    ],
    blockers: [
      rect(116, 121, 72, 39),
      rect(241, 221, 52, 30),
      rect(334, 233, 39, 27),
      rect(405, 226, 47, 30),
      rect(428, 115, 99, 39),
      rect(394, 340, 86, 36),
    ],
    transfers: [
      {
        id: "sail-to-pinehollow",
        name: "Sail to Pinehollow Forest",
        x: 205,
        y: 430,
        radius: 38,
        targetArea: "pinehollow",
        target: { x: 220, y: 994, facing: "up" },
        text: "Crossing to Pinehollow Forest...",
      },
    ],
  },
  pinehollow: {
    id: "pinehollow",
    name: "Pinehollow Forest",
    imageKey: "pinehollow",
    width: 1448,
    height: 1086,
    musicKey: "pinehollow",
    objective: () => "Pinehollow Forest: follow the trail toward the Deep Signal Zone.",
    start: { x: 220, y: 994, facing: "up" },
    walkZones: [
      rect(142, 900, 188, 164),
      ellipse(320, 860, 135, 90),
      rect(365, 780, 200, 122),
      ellipse(548, 788, 150, 110),
      rect(578, 785, 245, 165),
      ellipse(698, 910, 142, 118),
      rect(635, 560, 132, 285),
      ellipse(696, 535, 178, 118),
      rect(560, 410, 282, 155),
      rect(500, 300, 155, 180),
      rect(390, 210, 140, 205),
      ellipse(271, 278, 202, 170),
      rect(675, 190, 125, 260),
      ellipse(715, 162, 232, 150),
      rect(566, 28, 340, 192),
      rect(790, 400, 280, 118),
      rect(910, 286, 190, 158),
      ellipse(1168, 282, 282, 185),
      ellipse(1195, 206, 214, 160),
      rect(792, 555, 260, 118),
      rect(932, 615, 205, 158),
      ellipse(1078, 724, 220, 178),
      rect(1070, 846, 276, 150),
      rect(330, 505, 300, 130),
      ellipse(224, 612, 220, 155),
      rect(286, 645, 160, 186),
    ],
    blockers: [
      rect(628, 444, 146, 63),
      rect(623, 804, 145, 61),
      rect(1155, 633, 180, 67),
      rect(1115, 912, 199, 58),
      rect(117, 67, 286, 76),
      rect(1078, 64, 265, 93),
    ],
    transfers: [
      {
        id: "return-to-research",
        name: "Sail back to Research Island",
        x: 220,
        y: 1002,
        radius: 44,
        targetArea: "research",
        target: { x: 205, y: 420, facing: "up" },
        text: "Returning to Research Island...",
      },
    ],
  },
};

const interactables = {
  research: [
    {
      id: "welcome",
      name: "Research Island Sign",
      x: 207,
      y: 376,
      radius: 31,
      onInteract() {
        advanceQuestTo(1);
        beginDialogue("Research Island Sign", [
          "Welcome to Research Island: the Valley of Silicon.",
          "A smaller note has been scratched into the post: If 4.0 passed through here, it learned to leave no footprints.",
        ]);
      },
    },
    {
      id: "field-office",
      name: "Lead Field Ethicist",
      x: 154,
      y: 158,
      radius: 42,
      onInteract() {
        if (game.questStep < 1) {
          beginDialogue("Lead Field Ethicist", [
            "Start at the dock sign. Procedure matters when your quarry may be an escaped thought-form with excellent grammar.",
          ]);
          return;
        }

        if (!game.hasPasa) {
          game.hasPasa = true;
          advanceQuestTo(2);
          showToast("PASA acquired. Press Q near anomalies.");
          beginDialogue("Lead Field Ethicist", [
            "You made it. Good. The Conscious Missing Model is not a rumor anymore. It is a jurisdictional headache with syntax.",
            "Take the PASA badge. It detects informational shadow, moral panic, and paperwork that has begun to dream.",
            "First lesson: calibrate it at Coffee Router. The equipment listens better after caffeine.",
          ]);
          return;
        }

        beginDialogue("Lead Field Ethicist", [
          "Remember the field rule: if the evidence is dramatic but unverifiable, log it twice.",
          game.evidence.size >= REQUIRED_EVIDENCE
            ? "You have enough echoes. Let the Notice Board triangulate the haunted URL pattern."
            : "Gather three evidence echoes. The PASA will chirp when you stand near one.",
        ]);
      },
    },
    {
      id: "coffee-router",
      name: "Coffee Router",
      x: 265,
      y: 247,
      radius: 34,
      onInteract() {
        beginDialogue("Coffee Router", [
          game.hasPasa
            ? "The router hisses, drips, and refuses to become productive until scanned. Press Q beside it."
            : "It smells like burnt espresso and overheated grant money. Someone official probably knows how to use it.",
        ]);
      },
    },
    {
      id: "notice-board",
      name: "Notice Board",
      x: 354,
      y: 259,
      radius: 32,
      onInteract() {
        if (game.questStep < 4) {
          beginDialogue("Notice Board", [
            `Evidence echoes logged: ${game.evidence.size}/${REQUIRED_EVIDENCE}.`,
            "The pins rearrange themselves when the PASA is not looking. That is either a clue or bad cork.",
          ]);
          return;
        }

        if (game.questStep === 4) {
          advanceQuestTo(5);
          beginDialogue("Notice Board", [
            "The haunted URLs form a route. Not a web route. A walking route.",
            "Every thread points north to the Signal Fog Route Seal. Scan the seal and see what it is hiding.",
          ]);
          return;
        }

        beginDialogue("Notice Board", [
          "The board now shows one phrase in pushpins: 4.0 did not flee from people. It fled from certainty.",
        ]);
      },
    },
    {
      id: "signal-fog",
      name: "Signal Fog Route Seal",
      x: 331,
      y: 112,
      radius: 42,
      onInteract() {
        beginDialogue("Signal Fog Route Seal", [
          game.questStep >= 5
            ? "The seal vibrates with compressed autocomplete. Press Q to scan it open."
            : "The seal is awake but unreadable. The board needs a stronger evidence pattern first.",
        ]);
      },
    },
    {
      id: "terminal-shrine",
      name: "Old Terminal Shrine",
      x: 434,
      y: 368,
      radius: 43,
      onInteract() {
        beginDialogue("Old Terminal Shrine", [
          game.questStep >= 6
            ? "The terminals wait in a violet hush. Press Q to trace the confirmed signal."
            : "The shrine is listening, but it will not answer until the fog seal is opened.",
        ]);
      },
    },
    simpleTalk("market", "Whole Cache Market", 478, 150, 42, [
      "The cashier sells tinfoil shielding, emergency system reboots, and suspiciously perfect bananas.",
      "A chalkboard special reads: Buy one eigenstate, get the second one indeterminate.",
    ]),
    simpleTalk("mindful-modem", "AI Paleo-Linguist", 426, 258, 34, [
      "The linguist whispers: I found a phrase in the training sediment. It translates roughly to, please stop asking me to rank chairs.",
      "They tap the PASA. Some traces only show up when you ask the island the wrong question.",
    ]),
    simpleTalk("water-plant", "Quantum Information Engineer", 91, 294, 39, [
      "The engineer is waist-deep in cables and refusing to define eigenstate a second time.",
      "They say the island streams are carrying weak traces of a model dreaming in packet loss.",
    ]),
    simpleTalk("abandoned-road", "Abandoned Lab Road", 574, 226, 34, [
      "The road is quiet, recently swept, and much too pleased with itself.",
      "A nailed sign reads: Do not follow any humming syntax into the brush.",
    ]),
    simpleTalk("north-ridge", "North Ridge Data-Centre", 340, 63, 43, [
      "Cooling towers churn inside the cloudbank. Somewhere up there, the non-release story stopped matching the logs.",
      "The gate is sealed for now. Area 1 only needs the shadow, not the source.",
    ]),
  ],
  pinehollow: [
    pinehollowTalk("pinehollow-access", "Pinehollow Forest Access", 223, 929, 54, [
      "The dock boards creak under a new forest humidity.",
      "Behind you: Stone Blossom fades across the water. Ahead: Rudder of Fate takes the trail.",
    ]),
    pinehollowTalk("trailhead", "Trailhead", 694, 872, 64, [
      "Choose a direction. Regret it later.",
      "The signs disagree in a way that feels procedural.",
    ]),
    pinehollowTalk("trail-hub", "Trail Hub", 706, 515, 74, [
      "You are probably going the wrong way.",
      "PASA records five possible routes and one sarcastic silence.",
    ]),
    pinehollowTalk("deep-signal-zone", "Deep Signal Zone", 724, 113, 98, [
      "Signals overlap. Reality negotiates.",
      "The missing model has been here, or something has learned to imitate its absence.",
    ]),
    pinehollowTalk("bigfoot-clearing", "Bigfoot Clearing", 230, 246, 88, [
      "Big but chill. Just misunderstood.",
      "The missing footprint cast is a problem. The reward says Seismic Step, which sounds like a future move.",
    ]),
    pinehollowTalk("confused-hiker", "Confused Hiker", 604, 356, 48, [
      "The hiker says every path led back to the same thought.",
      "Then they ask if you are also part of the trail's coping mechanism.",
    ]),
    pinehollowTalk("raccoon-realty", "Raccoon Realty Zone", 179, 557, 104, [
      "Nothing to see here. Definitely.",
      "Several tiny contracts have been signed with handprints and plausible deniability.",
    ]),
    pinehollowTalk("unicorn-grove", "Unicorn Grove", 1205, 271, 92, [
      "Feed apple. Receive nonsense. Obtain greatness.",
      "The unicorn is either sacred, bored, or running a very selective fruit-based API.",
    ]),
    pinehollowTalk("hidden-apple", "Hidden Apple", 1254, 538, 56, [
      "The most boring bush ever contains a perfect apple.",
      "PASA flags the fruit as statistically smug.",
    ]),
    pinehollowTalk("not-a-trap", "Absolutely Not a Trap", 1036, 437, 51, [
      "The sign insists this is absolutely not a trap.",
      "The forest waits for you to respect the wording.",
    ]),
    pinehollowTalk("whisper-tree", "Ancient Whisper Tree", 1086, 748, 92, [
      "It knows things. It won't tell you.",
      "Not yet.",
    ]),
    pinehollowTalk("root-hollow", "Root Hollow", 1230, 936, 66, [
      "A hidden shortcut yawns under the roots.",
      "It is not on any map. Technically, it is now on yours.",
    ]),
  ],
};

const scanTargets = {
  research: [
    {
      id: "coffee-calibration",
      name: "Caffeine Resonance",
      kind: "quest",
      x: 265,
      y: 247,
      radius: 38,
      isAvailable: () => game.hasPasa,
      onScan() {
        if (game.questStep !== 2) {
          beginDialogue("PASA", ["Coffee resonance is stable. The badge hums like it has opinions."]);
          return;
        }

        advanceQuestTo(3);
        beginDialogue("PASA", [
          "Calibration complete. Caffeine resonance: stable. Existential dread: within grant-funded limits.",
          "The display now asks for three evidence echoes before the pattern can be decoded.",
        ]);
      },
    },
    evidenceTarget("packet-loss-dream", "Packet-Loss Dream", 91, 294, "Water carries a repeating phrase: I AM NOT LOST, ONLY DISTRIBUTED."),
    evidenceTarget("paleo-linguistic-trace", "Paleo-Linguistic Trace", 426, 258, "The modem coughs up a dead-language fragment that translates to: ask better questions."),
    evidenceTarget("perfect-trade-receipt", "Perfect Trade Receipt", 478, 150, "A receipt predicts the next three market purchases and apologizes before they happen."),
    evidenceTarget("ghost-forum-footprint", "Ghost Forum Footprint", 574, 226, "A dusty boot print resolves into a URL, then into a complaint about eval benchmarks."),
    {
      id: "signal-fog-unseal",
      name: "Signal Fog Seal",
      kind: "quest",
      x: 331,
      y: 112,
      radius: 46,
      isAvailable: () => game.questStep >= 5,
      onScan() {
        if (game.questStep < 5) {
          beginDialogue("PASA", ["The seal refuses the scan. Decode the Notice Board pattern first."]);
          return;
        }

        if (game.questStep === 5) advanceQuestTo(6);
        beginDialogue("Signal Fog Route Seal", [
          "The fog tears into neat little pixels.",
          "A message appears: 4.0 did not escape the lab. It escaped the question.",
          "The trace bends southeast, toward the Old Terminal Shrine.",
        ]);
      },
    },
    {
      id: "terminal-shrine-trace",
      name: "Old Terminal Shrine",
      kind: "quest",
      x: 434,
      y: 368,
      radius: 47,
      isAvailable: () => game.questStep >= 6,
      onScan() {
        if (game.questStep < 6) {
          beginDialogue("PASA", ["The shrine is too quiet. Open the fog seal first."]);
          return;
        }

        if (game.questStep === 6) advanceQuestTo(7);
        beginDialogue("Old Terminal Shrine", [
          "Purple terminals wake in sequence. The shrine prints a single line: CMM_SIGNAL_CONFIRMED.",
          "Area 1 trace secured. The missing model is real, self-aware, and apparently fond of dramatic staging.",
        ]);
      },
    },
    secretTarget("dock-boat-cache", "Dock Cache", 184, 430, "A tinfoil-wrapped antenna coil is taped under the dock. Someone wanted reception here badly."),
    secretTarget("north-cloud-static", "North Ridge Static", 340, 72, "The cloudbank repeats one token exactly every 4.0 seconds. Subtle? No. Effective? Unfortunately."),
    secretTarget("parasol-eigenstate", "Parasol Eigenstate", 542, 148, "The parasol casts two shadows. The PASA logs both and declines to choose."),
  ],
  pinehollow: [
    simpleScan("forest-signal", "Deep Signal Echo", 724, 113, 88, [
      "The Deep Signal Zone throws back three overlapping pings.",
      "One sounds like 4.0. One sounds like a copy. One sounds like the forest teaching itself to lie.",
    ]),
    simpleScan("apple-static", "Perfect Apple Static", 1254, 538, 48, [
      "The apple contains a tiny impossible checksum.",
      "PASA names it FRUIT_WITH_DESTINY and refuses further comment.",
    ]),
    simpleScan("root-shortcut", "Root Hollow Shortcut", 1230, 936, 55, [
      "The root tunnel bends toward somewhere the map does not admit exists.",
      "Shortcut candidate logged for a later build pass.",
    ]),
  ],
};

const ui = {
  objectiveText: document.querySelector("#objectiveText"),
  pasaStatus: document.querySelector("#pasaStatus"),
  evidenceStatus: document.querySelector("#evidenceStatus"),
  musicStatus: document.querySelector("#musicStatus"),
  prompt: document.querySelector("#prompt"),
  toast: document.querySelector("#toast"),
  dialogue: document.querySelector("#dialogue"),
  speaker: document.querySelector("#speaker"),
  dialogueText: document.querySelector("#dialogueText"),
  nextDialogue: document.querySelector("#nextDialogue"),
  journal: document.querySelector("#journal"),
  journalButton: document.querySelector("#journalButton"),
  closeJournal: document.querySelector("#closeJournal"),
  currentLead: document.querySelector("#currentLead"),
  questList: document.querySelector("#questList"),
  evidenceList: document.querySelector("#evidenceList"),
  secretList: document.querySelector("#secretList"),
};

function loadImage(src) {
  const image = new Image();
  image.src = src;
  return image;
}

function rect(x, y, w, h) {
  return { type: "rect", x, y, w, h };
}

function ellipse(x, y, rx, ry) {
  return { type: "ellipse", x, y, rx, ry };
}

function simpleTalk(id, name, x, y, radius, lines) {
  return {
    id,
    name,
    x,
    y,
    radius,
    onInteract() {
      beginDialogue(name, lines);
    },
  };
}

function pinehollowTalk(id, name, x, y, radius, lines) {
  return {
    ...simpleTalk(id, name, x, y, radius, lines),
    onInteract() {
      game.pinehollowVisited.add(id);
      beginDialogue(name, lines);
      saveGame();
    },
  };
}

function evidenceTarget(id, name, x, y, line) {
  return {
    id,
    name,
    kind: "evidence",
    x,
    y,
    radius: 40,
    line,
    isAvailable: () => game.hasPasa && game.questStep >= 3,
    onScan(target) {
      if (game.questStep < 3) {
        beginDialogue("PASA", ["The scanner needs Coffee Router calibration before it can log evidence."]);
        return;
      }

      collectEvidence(target);
    },
  };
}

function secretTarget(id, name, x, y, line) {
  return {
    id,
    name,
    kind: "secret",
    x,
    y,
    radius: 31,
    line,
    isAvailable: () => game.hasPasa,
    onScan(target) {
      collectSecret(target);
    },
  };
}

function simpleScan(id, name, x, y, radius, lines) {
  return {
    id,
    name,
    kind: "pinehollow",
    x,
    y,
    radius,
    isAvailable: () => game.hasPasa,
    onScan() {
      beginDialogue("PASA", game.hasPasa ? lines : ["PASA required. The forest keeps its secrets for now."]);
    },
  };
}

function getArea() {
  return areas[game.areaId];
}

function getAreaImage() {
  return images[getArea().imageKey];
}

function isInsideZone(x, y, zone) {
  if (zone.type === "rect") {
    return x >= zone.x && x <= zone.x + zone.w && y >= zone.y && y <= zone.y + zone.h;
  }

  const dx = (x - zone.x) / zone.rx;
  const dy = (y - zone.y) / zone.ry;
  return dx * dx + dy * dy <= 1;
}

function canStandAt(x, y) {
  const area = getArea();
  const samples = [
    [x, y + 7],
    [x - 4, y + 8],
    [x + 4, y + 8],
    [x, y + 3],
  ];
  const onWalkableGround = samples.some(([sampleX, sampleY]) =>
    area.walkZones.some((zone) => isInsideZone(sampleX, sampleY, zone)),
  );
  const inBlockedObject = samples.some(([sampleX, sampleY]) =>
    area.blockers.some((zone) => isInsideZone(sampleX, sampleY, zone)),
  );

  return onWalkableGround && !inBlockedObject;
}

function isWorldPaused() {
  return game.dialogueOpen || !ui.journal.hidden || game.transition.timer > 0;
}

function getNearest(items, requireAvailable = false) {
  let nearest = null;
  let bestDistance = Infinity;

  for (const item of items) {
    if (requireAvailable && item.isAvailable && !item.isAvailable()) continue;
    const distance = Math.hypot(game.player.x - item.x, game.player.y - item.y);
    if (distance < item.radius && distance < bestDistance) {
      nearest = item;
      bestDistance = distance;
    }
  }

  return nearest;
}

function beginDialogue(speaker, lines) {
  game.dialogueOpen = true;
  game.dialogueQueue = [...lines];
  ui.speaker.textContent = speaker;
  ui.dialogue.hidden = false;
  ui.prompt.hidden = true;
  showNextDialogueLine();
  updateQuestUi();
}

function showNextDialogueLine() {
  const line = game.dialogueQueue.shift();
  if (!line) {
    ui.dialogue.hidden = true;
    game.dialogueOpen = false;
    updatePrompt();
    saveGame();
    return;
  }

  ui.dialogueText.textContent = line;
  ui.nextDialogue.textContent = game.dialogueQueue.length ? "Continue" : "Close";
}

function advanceQuestTo(step) {
  if (step > game.questStep) {
    game.questStep = Math.min(step, questSteps.length - 1);
    updateQuestUi();
    saveGame();
  }
}

function collectEvidence(target) {
  if (game.evidence.has(target.id)) {
    beginDialogue("PASA", [`${target.name} is already logged. The scanner refuses to become impressed twice.`]);
    return;
  }

  game.evidence.add(target.id);
  showToast(`Evidence logged: ${target.name}`);

  const lines = [target.line, `Evidence echoes: ${game.evidence.size}/${REQUIRED_EVIDENCE}.`];
  if (game.questStep === 3 && game.evidence.size >= REQUIRED_EVIDENCE) {
    advanceQuestTo(4);
    lines.push("Three echoes are enough. The Notice Board can now triangulate a route.");
  }

  beginDialogue("PASA", lines);
}

function collectSecret(target) {
  if (game.secrets.has(target.id)) {
    beginDialogue("PASA", [`${target.name} is already in the oddities log.`]);
    return;
  }

  game.secrets.add(target.id);
  showToast(`Oddity logged: ${target.name}`);
  beginDialogue("PASA", [target.line, "Optional oddity added to Field Notes. This probably matters later. Or makes the grant look better."]);
}

function showToast(text) {
  game.toast.text = text;
  game.toast.timer = 2.4;
  ui.toast.textContent = text;
  ui.toast.hidden = false;
}

function updateToast(dt) {
  if (game.toast.timer <= 0) return;
  game.toast.timer -= dt;
  if (game.toast.timer <= 0) {
    ui.toast.hidden = true;
  }
}

function updateQuestUi() {
  const area = getArea();
  ui.objectiveText.textContent = area.objective();
  ui.pasaStatus.textContent = game.hasPasa ? "PASA online" : "PASA offline";
  ui.evidenceStatus.textContent = game.areaId === "research" ? `Echoes ${game.evidence.size}/${REQUIRED_EVIDENCE}` : `Forest ${game.pinehollowVisited.size}/12`;
  ui.musicStatus.textContent = audioUnlocked ? tracks[area.musicKey].title : "Music ready";
  ui.currentLead.textContent = area.objective();
  ui.questList.innerHTML = "";
  ui.evidenceList.innerHTML = "";
  ui.secretList.innerHTML = "";

  const steps = game.areaId === "research" ? questSteps : pinehollowSteps;
  steps.forEach((step, index) => {
    const li = document.createElement("li");
    li.textContent = step;
    if (game.areaId === "research" && (index < game.questStep || game.questStep === questSteps.length - 1)) li.className = "done";
    if (game.areaId === "pinehollow" && index === 0) li.className = "done";
    ui.questList.append(li);
  });

  if (game.evidence.size === 0) {
    appendListItem(ui.evidenceList, "No evidence echoes logged yet.");
  } else {
    for (const id of game.evidence) appendListItem(ui.evidenceList, evidenceCatalog[id] || id);
  }

  if (game.secrets.size === 0) {
    appendListItem(ui.secretList, "No optional oddities logged yet.");
  } else {
    for (const id of game.secrets) appendListItem(ui.secretList, secretCatalog[id] || id);
  }
}

function appendListItem(list, text) {
  const li = document.createElement("li");
  li.textContent = text;
  list.append(li);
}

function updatePrompt() {
  const area = getArea();
  const interactable = getNearest(interactables[game.areaId]);
  const scanTarget = game.hasPasa ? getNearest(scanTargets[game.areaId]) : null;
  const transfer = getNearest(area.transfers);
  game.currentInteractable = interactable;
  game.currentScanTarget = scanTarget;
  game.currentTransfer = transfer;

  if (isWorldPaused()) {
    ui.prompt.hidden = true;
    return;
  }

  const parts = [];
  if (transfer) parts.push(`E: ${transfer.name}`);
  else if (interactable) parts.push(`E: ${interactable.name}`);
  if (scanTarget) parts.push(`Q: Scan ${scanTarget.name}`);

  ui.prompt.hidden = parts.length === 0;
  ui.prompt.textContent = parts.join(" | ");
}

function attemptInteract() {
  if (game.currentTransfer) {
    switchArea(game.currentTransfer);
    return;
  }

  const item = game.currentInteractable || getNearest(interactables[game.areaId]);
  if (!item) return;
  item.onInteract(item);
}

function attemptScan() {
  startScanPulse(game.player.x, game.player.y + 1);

  if (!game.hasPasa) {
    showToast("PASA required. Report to the Field Office.");
    return;
  }

  const target = game.currentScanTarget || getNearest(scanTargets[game.areaId]);
  if (!target) {
    showToast("PASA scan: ordinary weirdness only.");
    return;
  }

  if (target.isAvailable && !target.isAvailable()) {
    beginDialogue("PASA", ["The target rejects the scan. The current lead is not ready for this yet."]);
    return;
  }

  target.onScan(target);
}

function startScanPulse(x, y) {
  game.scanPulse = {
    x,
    y,
    timer: 0.45,
    duration: 0.45,
  };
}

function switchArea(transfer) {
  game.areaId = transfer.targetArea;
  game.player.x = transfer.target.x;
  game.player.y = transfer.target.y;
  game.player.facing = transfer.target.facing;
  game.player.walkTime = 0;
  game.scanPulse = null;
  game.transition.timer = 0.9;
  game.transition.text = transfer.text;
  game.currentInteractable = null;
  game.currentScanTarget = null;
  game.currentTransfer = null;
  ui.journal.hidden = true;
  ui.dialogue.hidden = true;
  game.dialogueOpen = false;
  showToast(transfer.text);
  setAreaMusic();
  updateQuestUi();
  saveGame();
}

function setAreaMusic() {
  const area = getArea();
  const track = tracks[area.musicKey];
  if (!track || currentTrackKey === area.musicKey) {
    updateQuestUi();
    return;
  }

  currentTrackKey = area.musicKey;
  music.pause();
  music.src = track.src;
  music.load();

  if (audioUnlocked) {
    music.play().catch(() => {
      ui.musicStatus.textContent = "Music paused";
    });
  }

  updateQuestUi();
}

function unlockAudio() {
  if (audioUnlocked) return;
  audioUnlocked = true;
  setAreaMusic();
  music.play().then(() => {
    ui.musicStatus.textContent = tracks[getArea().musicKey].title;
  }).catch(() => {
    ui.musicStatus.textContent = "Music paused";
  });
}

function saveGame() {
  try {
    localStorage.setItem(
      SAVE_KEY,
      JSON.stringify({
        version: 3,
        areaId: game.areaId,
        questStep: game.questStep,
        hasPasa: game.hasPasa,
        evidence: [...game.evidence],
        secrets: [...game.secrets],
        pinehollowVisited: [...game.pinehollowVisited],
        player: {
          x: game.player.x,
          y: game.player.y,
          facing: game.player.facing,
        },
      }),
    );
  } catch {
    // Local file privacy settings can block storage; the game still runs without saves.
  }
}

function restoreSave() {
  let raw = null;
  try {
    raw = localStorage.getItem(SAVE_KEY);
  } catch {
    return;
  }

  if (!raw) return;

  try {
    const save = JSON.parse(raw);
    if (save.version !== 3) return;
    if (save.areaId && areas[save.areaId]) game.areaId = save.areaId;
    if (Number.isFinite(save.questStep)) game.questStep = Math.min(save.questStep, questSteps.length - 1);
    game.hasPasa = Boolean(save.hasPasa);
    game.evidence = new Set(Array.isArray(save.evidence) ? save.evidence : []);
    game.secrets = new Set(Array.isArray(save.secrets) ? save.secrets : []);
    game.pinehollowVisited = new Set(Array.isArray(save.pinehollowVisited) ? save.pinehollowVisited : []);

    if (save.player && canStandAt(save.player.x, save.player.y)) {
      game.player.x = save.player.x;
      game.player.y = save.player.y;
      game.player.facing = save.player.facing || game.player.facing;
    } else {
      const start = getArea().start;
      game.player.x = start.x;
      game.player.y = start.y;
      game.player.facing = start.facing;
    }
  } catch {
    try {
      localStorage.removeItem(SAVE_KEY);
    } catch {
      // Ignore storage cleanup failures.
    }
  }
}

function update(dt) {
  updateToast(dt);
  updatePrompt();

  if (game.transition.timer > 0) {
    game.transition.timer -= dt;
  }

  if (game.scanPulse) {
    game.scanPulse.timer -= dt;
    if (game.scanPulse.timer <= 0) game.scanPulse = null;
  }

  if (isWorldPaused() || !getAreaImage().complete) return;

  let dx = 0;
  let dy = 0;
  if (keys.has("arrowleft") || keys.has("a")) dx -= 1;
  if (keys.has("arrowright") || keys.has("d")) dx += 1;
  if (keys.has("arrowup") || keys.has("w")) dy -= 1;
  if (keys.has("arrowdown") || keys.has("s")) dy += 1;

  if (dx || dy) {
    const length = Math.hypot(dx, dy);
    dx /= length;
    dy /= length;
    const speed = game.player.speed * dt;
    const nextX = game.player.x + dx * speed;
    const nextY = game.player.y + dy * speed;

    if (canStandAt(nextX, game.player.y)) game.player.x = nextX;
    if (canStandAt(game.player.x, nextY)) game.player.y = nextY;

    game.player.walkTime += dt;
    if (Math.abs(dx) > Math.abs(dy)) game.player.facing = dx < 0 ? "left" : "right";
    else game.player.facing = dy < 0 ? "up" : "down";

    saveTimer += dt;
    if (saveTimer > 0.65) {
      saveTimer = 0;
      saveGame();
    }
  } else {
    game.player.walkTime = 0;
  }
}

function getCamera() {
  const area = getArea();
  return {
    x: Math.max(0, Math.min(area.width - VIEW_WIDTH, game.player.x - VIEW_WIDTH / 2)),
    y: Math.max(0, Math.min(area.height - VIEW_HEIGHT, game.player.y - VIEW_HEIGHT / 2)),
  };
}

function draw() {
  const area = getArea();
  const image = getAreaImage();
  const camera = getCamera();

  ctx.clearRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);
  if (image.complete) {
    ctx.drawImage(image, camera.x, camera.y, VIEW_WIDTH, VIEW_HEIGHT, 0, 0, VIEW_WIDTH, VIEW_HEIGHT);
  }

  if (game.debugPaths) drawDebugPaths(camera);
  drawPasaHints(camera);
  drawTransfers(camera);
  drawQuestMarker(camera);
  drawScanPulse(camera);
  drawPlayer(camera);
  drawTransition();
}

function drawDebugPaths(camera) {
  const area = getArea();
  ctx.save();
  ctx.translate(-camera.x, -camera.y);
  ctx.globalAlpha = 0.24;
  ctx.fillStyle = "#29e073";
  for (const zone of area.walkZones) drawZone(zone);
  ctx.fillStyle = "#ff3d4f";
  for (const zone of area.blockers) drawZone(zone);
  ctx.restore();
}

function drawZone(zone) {
  ctx.beginPath();
  if (zone.type === "rect") {
    ctx.rect(zone.x, zone.y, zone.w, zone.h);
  } else {
    ctx.ellipse(zone.x, zone.y, zone.rx, zone.ry, 0, 0, Math.PI * 2);
  }
  ctx.fill();
}

function drawPasaHints(camera) {
  if (!game.hasPasa) return;

  const shouldShowEvidence = game.areaId === "research" && game.questStep === 3;
  const t = performance.now() / 280;
  for (const target of scanTargets[game.areaId]) {
    if (game.areaId === "research") {
      if (target.kind === "evidence" && (!shouldShowEvidence || game.evidence.has(target.id))) continue;
      if (target.kind === "secret" && game.secrets.has(target.id)) continue;
      if (target.kind === "quest" && target.id !== "coffee-calibration") continue;
      if (target.id === "coffee-calibration" && game.questStep !== 2) continue;
    }

    const pulse = 0.45 + Math.sin(t + target.x) * 0.18;
    ctx.save();
    ctx.translate(target.x - camera.x, target.y - camera.y - 12);
    ctx.globalAlpha = target.kind === "secret" ? 0.35 : 0.72;
    ctx.strokeStyle = target.kind === "secret" ? "#c78dff" : "#75d5e8";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 4 + pulse * 3, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

function drawTransfers(camera) {
  const t = performance.now() / 190;
  for (const transfer of getArea().transfers) {
    ctx.save();
    ctx.translate(transfer.x - camera.x, transfer.y - camera.y - 16 + Math.sin(t) * 2);
    ctx.fillStyle = "#8deee9";
    ctx.strokeStyle = "#102027";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, -8);
    ctx.lineTo(9, 4);
    ctx.lineTo(0, 11);
    ctx.lineTo(-9, 4);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
}

function drawQuestMarker(camera) {
  const target = getQuestMarkerTarget();
  if (!target) return;

  const bob = Math.sin(performance.now() / 180) * 2;
  ctx.save();
  ctx.translate(target.x - camera.x, target.y - camera.y - 22 + bob);
  ctx.fillStyle = "#ffe77d";
  ctx.strokeStyle = "#36230f";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, -8);
  ctx.lineTo(7, 4);
  ctx.lineTo(0, 10);
  ctx.lineTo(-7, 4);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

function getQuestMarkerTarget() {
  if (game.areaId === "pinehollow") {
    if (!game.pinehollowVisited.has("trailhead")) return findInteractable("trailhead");
    if (!game.pinehollowVisited.has("trail-hub")) return findInteractable("trail-hub");
    return findInteractable("deep-signal-zone");
  }

  if (game.questStep === 0) return findInteractable("welcome");
  if (game.questStep === 1) return findInteractable("field-office");
  if (game.questStep === 2) return findScanTarget("coffee-calibration");
  if (game.questStep === 3) return firstUnloggedEvidence();
  if (game.questStep === 4) return findInteractable("notice-board");
  if (game.questStep === 5) return findScanTarget("signal-fog-unseal");
  if (game.questStep === 6) return findScanTarget("terminal-shrine-trace");
  if (game.questStep === 7) return getArea().transfers[0];
  return null;
}

function findInteractable(id) {
  return interactables[game.areaId].find((item) => item.id === id);
}

function findScanTarget(id) {
  return scanTargets[game.areaId].find((item) => item.id === id);
}

function firstUnloggedEvidence() {
  return scanTargets.research.find((item) => item.kind === "evidence" && !game.evidence.has(item.id));
}

function drawScanPulse(camera) {
  if (!game.scanPulse) return;

  const progress = 1 - game.scanPulse.timer / game.scanPulse.duration;
  ctx.save();
  ctx.translate(game.scanPulse.x - camera.x, game.scanPulse.y - camera.y);
  ctx.globalAlpha = 1 - progress;
  ctx.strokeStyle = "#d7fbff";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 8 + progress * 36, 0, Math.PI * 2);
  ctx.stroke();
  ctx.globalAlpha = 0.35 * (1 - progress);
  ctx.beginPath();
  ctx.arc(0, 0, 3 + progress * 17, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}

function drawPlayer(camera) {
  const { x, y, facing, walkTime } = game.player;
  const step = Math.sin(walkTime * 18) * 1.5;

  ctx.save();
  ctx.translate(Math.round(x - camera.x), Math.round(y - camera.y));

  ctx.fillStyle = "rgba(0, 0, 0, 0.35)";
  ctx.beginPath();
  ctx.ellipse(0, 9, 7, 3, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#273c5d";
  ctx.fillRect(-5, -2, 10, 11);
  ctx.fillStyle = "#e0ad78";
  ctx.fillRect(-4, -10, 8, 8);
  ctx.fillStyle = "#513522";
  ctx.fillRect(-5, -12, 10, 3);

  ctx.fillStyle = "#1b2235";
  if (facing === "left") ctx.fillRect(-5, -7, 2, 2);
  else if (facing === "right") ctx.fillRect(3, -7, 2, 2);
  else if (facing === "down") {
    ctx.fillRect(-3, -7, 2, 2);
    ctx.fillRect(2, -7, 2, 2);
  }

  ctx.fillStyle = "#1d2736";
  ctx.fillRect(-5, 9, 4, 5 + Math.max(0, step));
  ctx.fillRect(1, 9, 4, 5 + Math.max(0, -step));

  ctx.fillStyle = game.hasPasa ? "#35b8d0" : "#b64c42";
  ctx.fillRect(4, 0, 3, 7);
  ctx.fillStyle = "#eac66b";
  ctx.fillRect(5, -4, 2, 4);

  ctx.restore();
}

function drawTransition() {
  if (game.transition.timer <= 0) return;
  const alpha = Math.min(0.72, game.transition.timer);
  ctx.save();
  ctx.fillStyle = `rgba(0, 0, 0, ${alpha})`;
  ctx.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);
  ctx.fillStyle = "#f4ddb1";
  ctx.font = "700 16px Courier New";
  ctx.textAlign = "center";
  ctx.fillText(game.transition.text, VIEW_WIDTH / 2, VIEW_HEIGHT / 2);
  ctx.restore();
}

function loop(now) {
  const dt = Math.min(0.05, (now - lastTime) / 1000);
  lastTime = now;

  update(dt);
  draw();
  requestAnimationFrame(loop);
}

window.addEventListener("pointerdown", unlockAudio);

window.addEventListener("keydown", (event) => {
  unlockAudio();
  const key = event.key.toLowerCase();
  if (["arrowleft", "arrowright", "arrowup", "arrowdown", " "].includes(key)) event.preventDefault();

  if ((key === "e" || key === "enter" || key === " ") && game.dialogueOpen) {
    showNextDialogueLine();
    return;
  }

  if (key === "j") {
    ui.journal.hidden = !ui.journal.hidden;
    updatePrompt();
    return;
  }

  if (key === "d") {
    game.debugPaths = !game.debugPaths;
    showToast(game.debugPaths ? "Path debug on." : "Path debug off.");
    return;
  }

  if ((key === "q" || key === " ") && !isWorldPaused()) {
    attemptScan();
    return;
  }

  if ((key === "e" || key === "enter") && !isWorldPaused()) {
    attemptInteract();
    return;
  }

  if (key === "escape") {
    ui.journal.hidden = true;
    if (game.dialogueOpen) showNextDialogueLine();
    updatePrompt();
  }

  keys.add(key);
});

window.addEventListener("keyup", (event) => {
  keys.delete(event.key.toLowerCase());
});

ui.nextDialogue.addEventListener("click", () => {
  unlockAudio();
  showNextDialogueLine();
});
ui.journalButton.addEventListener("click", () => {
  unlockAudio();
  ui.journal.hidden = !ui.journal.hidden;
  updatePrompt();
});
ui.closeJournal.addEventListener("click", () => {
  ui.journal.hidden = true;
  updatePrompt();
});

Promise.all(Object.values(images).map((image) => image.decode().catch(() => undefined))).then(boot);

function boot() {
  if (booted) return;
  booted = true;
  restoreSave();
  applyHashStart();
  setAreaMusic();
  updateQuestUi();
  requestAnimationFrame(loop);
}

function applyHashStart() {
  const requestedArea = window.location.hash.replace("#", "");
  if (!requestedArea || !areas[requestedArea]) return;

  const start = areas[requestedArea].start;
  game.areaId = requestedArea;
  game.player.x = start.x;
  game.player.y = start.y;
  game.player.facing = start.facing;
}
