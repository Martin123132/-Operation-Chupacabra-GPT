# Operation Chupacabra-GPT: Research Island

The first playable area for a Zelda-like search for 4.0, the missing self-aware model.

Open `index.html` in a browser. The game uses the original Research Island and Pinehollow Forest artwork as base layers, then adds movement, collision, interactable landmarks, PASA scanning, evidence logging, optional oddities, save progress, music, and a field-notes HUD.

Open `area2.html` to view the second area map, Pinehollow Forest. This currently mirrors the first map-only pass: exact source artwork as the base layer, optional clickable regions, zoom, and panning.

Music:

- Area 1 uses `assets/stone-blossom.mp3`.
- Area 2 uses `assets/rudder-of-fate.mp3`.
- Browser audio starts after the first key press or click.

Controls:

- Move with arrow keys or WASD.
- Press `E` or `Enter` to inspect people, signs, and buildings.
- Press `E` at a dock transfer prompt to walk through between areas.
- Press `Q` to scan with PASA once the Field Office gives it to you.
- Press `J` to open or close Field Notes.
- Press `Esc` to close panels.
- Press `D` to toggle the path/debug overlay when tuning collision.

Area 1 quest chain:

1. Inspect the south dock welcome sign.
2. Report to the Field Office.
3. Calibrate PASA at Coffee Router.
4. Scan three evidence echoes around the island.
5. Decode the haunted URL pattern at the Notice Board.
6. Scan the Signal Fog Route Seal.
7. Read the anomaly at the Old Terminal Shrine.
8. Walk to the south dock and sail to Pinehollow Forest.
