# Area 2 Design Target

Pinehollow Forest is the second area after Research Island.

## Current Goal

Get the supplied forest map rendering correctly before adding movement, collision, scan routes, NPC logic, or progression.

## Map Identity

- Entry: Pinehollow Forest Access / Trailhead.
- Core hub: Trail Hub.
- Main mystery site: Deep Signal Zone.
- Character zones: Bigfoot Clearing, Unicorn Grove, Raccoon Realty Zone, Ancient Whisper Tree.
- Shortcut/gate candidate: Root Hollow.
- Secret candidate: Hidden Apple.

## First-Pass Implementation

- Uses the exact supplied 1448 x 1086 JPEG as the base artwork.
- Adds transparent hotspot regions for the major named areas.
- Keeps controls hidden until hover/focus so the default view is just the map.
- Supports zoom and panning for inspection.
- Is now connected to the main playable `index.html` build via the Research Island dock.
- Uses `assets/rudder-of-fate.mp3` as the Area 2 music track.

## Next Pass

- Add a player start at Trailhead.
- Tune the current first-pass Pinehollow path/collision zones by walking every branch.
- Use PASA scans for Deep Signal Zone, Ancient Whisper Tree, and Hidden Apple.
- Decide which route from Trailhead is the intended first route and which paths are soft-gated.
