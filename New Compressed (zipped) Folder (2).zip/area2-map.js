const MAP_WIDTH = 1448;
const MAP_HEIGHT = 1086;

const locations = [
  {
    title: "Trailhead",
    region: "Pinehollow Forest Access",
    description: "The Area 2 entry point. Every sign gives bad advice, which probably means one of them matters.",
    x: 591,
    y: 809,
    w: 185,
    h: 95,
  },
  {
    title: "Trail Hub",
    region: "Central Forest",
    description: "Main crossroad for the forest routes. The map claims you are probably going the wrong way.",
    x: 610,
    y: 437,
    w: 169,
    h: 102,
  },
  {
    title: "Deep Signal Zone",
    region: "North Ritual Clearing",
    description: "Signals overlap here. Reality negotiates. This is the likely Area 2 core objective site.",
    x: 615,
    y: 10,
    w: 215,
    h: 190,
  },
  {
    title: "Bigfoot Clearing",
    region: "North West Clearing",
    description: "A calm campfire clearing with a misunderstood resident and a missing footprint cast.",
    x: 122,
    y: 66,
    w: 286,
    h: 282,
  },
  {
    title: "Raccoon Realty Zone",
    region: "West Hollow",
    description: "A suspiciously organized property office. The sign insists there is nothing to see.",
    x: 51,
    y: 489,
    w: 290,
    h: 230,
  },
  {
    title: "Unicorn Grove",
    region: "North East Grove",
    description: "A glowing grove where one perfect apple appears to control the local nonsense economy.",
    x: 1076,
    y: 63,
    w: 282,
    h: 326,
  },
  {
    title: "Hidden Apple",
    region: "East Hedge",
    description: "The most boring bush in the forest, which makes it deeply suspicious.",
    x: 1186,
    y: 481,
    w: 186,
    h: 77,
  },
  {
    title: "Ancient Whisper Tree",
    region: "South East Rootfield",
    description: "It knows things. It won't tell you. Not yet.",
    x: 1013,
    y: 627,
    w: 330,
    h: 180,
  },
  {
    title: "Root Hollow",
    region: "South East Shortcut",
    description: "A hidden shortcut under the root mass. It is not on any map, including this one.",
    x: 1111,
    y: 895,
    w: 228,
    h: 101,
  },
  {
    title: "Pinehollow Dock",
    region: "South West Access",
    description: "A small dock and boat at the forest edge, probably where Area 1 hands off into Area 2.",
    x: 144,
    y: 904,
    w: 162,
    h: 154,
  },
  {
    title: "Confused Hiker",
    region: "North Central Path",
    description: "A person sitting in the most informative-looking place and still having a terrible time.",
    x: 546,
    y: 285,
    w: 94,
    h: 116,
  },
  {
    title: "Absolutely Not a Trap",
    region: "East Path",
    description: "The sign says it is absolutely not a trap. That settles it, obviously.",
    x: 979,
    y: 399,
    w: 134,
    h: 72,
  },
];

const viewport = document.querySelector("#mapViewport");
const stage = document.querySelector("#mapStage");
const hotspots = document.querySelector("#hotspots");
const card = document.querySelector("#locationCard");
const closeCard = document.querySelector("#closeCard");
const cardTitle = document.querySelector("#cardTitle");
const cardRegion = document.querySelector("#cardRegion");
const cardDescription = document.querySelector("#cardDescription");

let baseScale = 1;
let zoom = 1;
let panX = 0;
let panY = 0;
let dragStart = null;

function renderHotspots() {
  hotspots.innerHTML = "";

  locations.forEach((location) => {
    const button = document.createElement("button");
    button.className = "hotspot";
    button.type = "button";
    button.setAttribute("aria-label", location.title);
    button.style.left = `${location.x}px`;
    button.style.top = `${location.y}px`;
    button.style.width = `${location.w}px`;
    button.style.height = `${location.h}px`;
    button.addEventListener("click", () => showLocation(location));
    hotspots.append(button);
  });
}

function showLocation(location) {
  cardTitle.textContent = location.title;
  cardRegion.textContent = location.region;
  cardDescription.textContent = location.description;
  card.hidden = false;
}

function measureBaseScale() {
  baseScale = Math.min(viewport.clientWidth / MAP_WIDTH, viewport.clientHeight / MAP_HEIGHT);
}

function updateTransform() {
  measureBaseScale();

  const scale = baseScale * zoom;
  const scaledWidth = MAP_WIDTH * scale;
  const scaledHeight = MAP_HEIGHT * scale;
  const minX = Math.min(0, viewport.clientWidth - scaledWidth);
  const minY = Math.min(0, viewport.clientHeight - scaledHeight);

  if (zoom <= 1) {
    panX = (viewport.clientWidth - scaledWidth) / 2;
    panY = (viewport.clientHeight - scaledHeight) / 2;
  } else {
    panX = Math.min(0, Math.max(minX, panX));
    panY = Math.min(0, Math.max(minY, panY));
  }

  stage.style.transform = `translate(${panX}px, ${panY}px) scale(${scale})`;
}

function setZoom(nextZoom) {
  const previousScale = baseScale * zoom;
  zoom = Math.min(2.75, Math.max(1, Number(nextZoom.toFixed(2))));

  if (zoom === 1) {
    panX = 0;
    panY = 0;
  } else {
    const nextScale = baseScale * zoom;
    const centerX = viewport.clientWidth / 2;
    const centerY = viewport.clientHeight / 2;
    panX = centerX - ((centerX - panX) / previousScale) * nextScale;
    panY = centerY - ((centerY - panY) / previousScale) * nextScale;
  }

  updateTransform();
}

document.querySelectorAll("[data-zoom]").forEach((button) => {
  button.addEventListener("click", () => {
    const action = button.dataset.zoom;
    if (action === "in") setZoom(zoom + 0.25);
    if (action === "out") setZoom(zoom - 0.25);
    if (action === "reset") setZoom(1);
  });
});

viewport.addEventListener("pointerdown", (event) => {
  if (zoom === 1) return;
  viewport.setPointerCapture(event.pointerId);
  dragStart = {
    x: event.clientX,
    y: event.clientY,
    panX,
    panY,
  };
});

viewport.addEventListener("pointermove", (event) => {
  if (!dragStart) return;
  panX = dragStart.panX + event.clientX - dragStart.x;
  panY = dragStart.panY + event.clientY - dragStart.y;
  updateTransform();
});

viewport.addEventListener("pointerup", () => {
  dragStart = null;
});

viewport.addEventListener("pointercancel", () => {
  dragStart = null;
});

window.addEventListener("keydown", (event) => {
  const step = event.shiftKey ? 56 : 28;

  if (event.key === "Escape") card.hidden = true;
  if (event.key === "+" || event.key === "=") setZoom(zoom + 0.25);
  if (event.key === "-") setZoom(zoom - 0.25);
  if (event.key === "0") setZoom(1);

  if (zoom === 1) return;
  if (event.key === "ArrowLeft" || event.key.toLowerCase() === "a") panX += step;
  if (event.key === "ArrowRight" || event.key.toLowerCase() === "d") panX -= step;
  if (event.key === "ArrowUp" || event.key.toLowerCase() === "w") panY += step;
  if (event.key === "ArrowDown" || event.key.toLowerCase() === "s") panY -= step;
  updateTransform();
});

closeCard.addEventListener("click", () => {
  card.hidden = true;
});

window.addEventListener("resize", updateTransform);

renderHotspots();
updateTransform();
